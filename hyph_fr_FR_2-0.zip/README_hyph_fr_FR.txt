Hyphenation dictionary
----------------------

Language: French (fr FR).  
Origin:   Based on the TeX hyphenation tables frhyph.tex (V2.12) <2002/12/11>
License:  GNU LGPL license.  
Author:   conversion author is Paul Pichaureau <paul.pichaureau@alcandre.net>

Based on a previous conversion by Blaise Drayer <blaise@drayer.ch>

This new version takes in account hyphenation of words with apostrophe '

This dictionary is based on syllable matching patterns and therefore should
be usable under other variations of French

HYPH fr FR hyph_fr_FR
HYPH fr CA hyph_fr_FR
