_______________________________________________________________________________

  Dictionnaire des césures pour le français (fr_FR)
  version 2.0
  
  Licence:  GNU LGPL.
  
  Origine: 	Basé sur les tables de césure de TeX : frhyph.tex (V2.12) <2002/12/11>
			http://mirror.ctan.org/language/hyphenation/frhyph.tex
			Les tables de césures de TeX sont publiées sous la licence LaTeX
			Project Public License (LPPL) -- http://www.latex-project.org/lppl.txt

  Licence: 	Les adaptations pour OpenOffice.org sont publiés sous la licence 
			GNU Lesser General Public License (LGPL)
			version 2.1 ou supérieure  --  http://www.gnu.org/licenses/

  Auteur:   auteur de la conversion, Paul Pichereau <paul.pichaureau@alcandre.net>
            Basé sur la précédente conversion par Blaise Drayer <blaise@drayer.ch>
			
  Journal:	tient compte des mots avec apostrophe.
  
  Ce dictionnaire devrait être conforme à toutes les variantes régionales du
  français.
  
_______________________________________________________________________________

  Hyphenation dictionary
  version 2.0
  
  Language: French (fr FR).
  
  License:  GNU LGPL.
  
  Origin:   Based on the TeX hyphenation tables frhyph.tex (V2.12) <2002/12/11>
			http://mirror.ctan.org/language/hyphenation/frhyph.tex
			The TeX hyphenation tables are released under the LaTeX Project
            Public License (LPPL) -- http://www.latex-project.org/lppl.txt
			
  License:  OpenOffice.org adaptions of this package are licensed under the
			GNU Lesser General Public License (LGPL)
			version 2.1 or higher  --  http://www.gnu.org/licenses/
			
  Author:   Conversion author is Paul Pichaureau <paul.pichaureau@alcandre.net>
			Based on a previous conversion by Blaise Drayer <blaise@drayer.ch>

  Log:		This version takes in account hyphenation of words with apostrophe '

  This dictionary is based on syllable matching patterns and therefore should
  be usable under other variations of French.
